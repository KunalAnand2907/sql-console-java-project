//package exception.properties;
EmptyFileNameException="Oops..Empty table name is not acceptable.....!"

