//package com.ncu.l;
import java.io.*;


class Book2{

Book2()
{
          

 
File c= null;
          try
          {
           File file = new File("test2.txt");
          FileReader fin = new FileReader(file);
	      BufferedReader bin= new BufferedReader(fin);

          String e="POSITION, TEAM NAME, MATCHES PLAYED, MATCHES WON, MATCHES LOST, POINTS, GOAL DIFFERENCE, WON,LOST";      
          String e1="1,LEICESTER CITY,35,33,1,100,62"; 
          String e2="2,ARSENAL,35,31,3,94,35";
          String e3="3,TOTTENHAM,35,26,3,79,56";
          String e4="4,MANCHESTER CITY,35,25,4,76,31";
          String e5="5,MANCHESTER UNITED,35,24,5,73,29";


          System.out.println("The contents of the file are: ");	
          System.out.println(e+"\n"+e1+"\n"+e2+"\n"+e3+"\n"+e4+"\n"+e5);
          }


catch (Exception e) 
         {
            // if any I/O error occurs
            e.printStackTrace();
         }  
	
}
}
