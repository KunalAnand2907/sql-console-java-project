import java.io.*;
import java.util.*;
//import com.ncu.*;

public class rem{

 



public static void removeRecord(){
      String file = "test3.txt";
   
    int removeTerm=3;
    Scanner x=new Scanner(System.in);

    String teFile= "test3.txt";
    File oldFile = new File(file);
    File newFile = new File(teFile);
    int POSITION =3,MATCHES_PLAYED =35,MATCHES_WON=26,MATCHES_LOST=3; 
    int POINTS =79,GOAL_DIFFERENCE=56;
    String TEAM_NAME= "NAPOLI";

    try {

        FileWriter fw = new FileWriter(teFile,true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        x = new Scanner(System.in);
        x.useDelimiter("[,\n]");

        while (x.hasNext())
        {
            POSITION = x.nextInt();
            TEAM_NAME = x.next();
            MATCHES_PLAYED = x.nextInt();
            MATCHES_WON= x.nextInt();
            MATCHES_LOST = x.nextInt();
            POINTS = x.nextInt();
            GOAL_DIFFERENCE= x.nextInt();

            if(POSITION!=removeTerm)
            {
                System.out.println(POSITION+ ","+ TEAM_NAME+","+MATCHES_PLAYED+","+MATCHES_WON+","+MATCHES_LOST+","+POINTS+","+GOAL_DIFFERENCE);

            }
        
        }
        x.close();
        pw.flush();
        pw.close();
        oldFile.delete();
        File dump = new File (file);
        newFile.renameTo(dump);
    }

    catch(Exception e)
    {
      System.out.println("ERROR!");
    }
}
}