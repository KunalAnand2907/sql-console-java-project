//package com.exception;
class WrongChoiceException extends Exception
{
WrongChoiceException(String s)
{
super(s);
}
}
