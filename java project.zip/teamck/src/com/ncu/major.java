import java.util.*;
import java.io.* ;
import org.apache.log4j.logger;
import org.apache.log4j.PropertyConfiguration;

//import com.ncu.l;
//import exception.properties;
//import package com.ncu.f;
//import com.ncu.properties:
class major
{
	
	public static void main(String[] args) 
	{

	
	
			Scanner scan = new Scanner(System.in);

			System.out.println("Enter one of the following choices or enter 0 to exit ");
			System.out.println("1.Insert rows.  2. Delete rows.  3. Display records of table.  4. Display all tables in the database. ") ;
			int a = scan.nextInt();
			Properties prop=new Properties();
		    FileInputStream input=null;
		    Logger logger=Logger.getLogger(major.class);
		    PropertyConfigurator.configure("home/arushi/teamc/configs/logger/logger.properties");
			

			try{
			input=new FileInputStream("exception.properties");
			prop.load(input);
			a=(EmptyFileNameException filename)
			}
			catch(EmptyFileNameException e)
			{
				logger.info(e);
				System.out.println(e);
				String s=prop.getProperties("EmptyFileNameException");
				System.out.println(s);
			}		
			switch(a)
				{
				case 0 : System.out.println("thank you ");
				break;

				case 1 :
				System.out.println("Press 1 for Book1.  Press 2 for Book2.  Press 3 for Book3 ");

				
				
				int b= scan.nextInt();

				switch(b)
				{
				case 1:
				System.out.println("Displaying Book1");
				Book1 r=new Book1();
				FileDemo g=new FileDemo();
				break;
				
				case 2: 
				System.out.println("Displaying Book2 ");
				Book2 e = new Book2();
				FileDemo l=new FileDemo();
				break;

				case 3:
                System.out.println("Displaying Book3");
                Book3 s=new Book3();
                FileDemo m=new FileDemo();
                break;
				}	
				break;

                
                case 2:

				System.out.println("Press 1 for Book1  Press 2 for Book2  Press 3 for Book3 ");
                int c=scan.nextInt();

                switch(c)
                {
                case 1:
                System.out.println("Displaying Book1  ");
				Book1 r=new Book1();
				remove e2=new remove();
                e2.remove();
                break;

                case 2:
                System.out.println("Displaying Book2 ");
				Book2 e = new Book2();
				RemoveALine e3=new RemoveALine();
				e3.RemoveALine();
				break;

                case 3:
                System.out.println("Displaying Book3");
                Book3 s=new Book3();
                break;
                }
                break;




                case 3:
                System.out.println("Press 1 for Book1\n Press 2 for Book2\n Press 3 for Book3 ");
                int p=scan.nextInt();
                try
                {
                input=new FileInputStream("exception.properties");
			    prop.load(input);
			    b=(ChoiceEnteredException filename)
			    }
			    catch(ChoiceEnteredException e)
			    {
				logger.info(e);
				System.out.println(e);
				String s=prop.getProperties("ChoiceEnteredException");
				System.out.println(s);
			    }		

                switch(p)
				{
				case 1:
				System.out.println("Displaying Book1  ");
				Book1 r=new Book1();
				break;
				
				case 2: 
				System.out.println("Displaying Book2 ");
				Book2 e = new Book2();
				break;

				case 3:
                System.out.println("Displaying Book3");
                Book3 s=new Book3();
                break;
				} 
				break;


				case 4:
				Book1 r=new Book1();
				Book2 e=new Book2();
				Book3 s=new Book3();
                break;


                case 5:
                System.out.println("error");

				}

				}
				}	
