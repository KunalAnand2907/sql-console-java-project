//package com.ncu.l;
import java.io.*;

class  Book3
{
Book3() 
{
	

	
		


File a= null;
            try 
            {
            	
         
          File filepath = new File("test3.txt");
          FileReader fin = new FileReader(filepath);
	      BufferedReader bin= new BufferedReader(fin);
          String s="POSITION,TEAM NAME,MATCHES PLAYED,MATCHES ,MATCHES ,POINTS,GOAL DIFFERENCE";   
          String s1="1,JUVENTUS,35,33,1,100,62";
          String s2="2,ROMA,35,31,3,94,35";
          String s3="3,NAPOLI,35,26,3,79,56";
          String s4="4,AC MILAN,35,25,4,76,31";
          String s5="5,INTER MILAN,35,24,5,73,29";
          
          System.out.println("the contents of the file are:");
          System.out.println(s+"\n"+s1+"\n"+s2+"\n"+s3+"\n"+s4+"\n"+s5);
            }

    catch (Exception e) 
         {
         	
            // if any I/O error occurs
            e.printStackTrace();
         }  
}
}
