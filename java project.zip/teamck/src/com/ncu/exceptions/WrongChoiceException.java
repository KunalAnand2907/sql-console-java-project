class WrongChoiceEnteredException extends Exception
{
WrongChoiceEnteredException(String s)
{
super(s);
}
}
