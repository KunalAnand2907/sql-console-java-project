//package com.exception;
class ChoiceEnteredException extends Exception
{
	ChoiceEnteredException(String s)
	{
		super(s);
	}
}
