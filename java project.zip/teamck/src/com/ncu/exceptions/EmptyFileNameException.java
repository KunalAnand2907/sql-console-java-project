//package exception;
class EmptyFileNameException extends Exception
{
EmptyFileNameException(String s)
{
super(s);
}
}
