//package com.ncu.l.*;
//package com.exception;
import java.util.*;
import java.io.*;

public class FileDemo {
   
      FileDemo() {
        
      
      Scanner scan=new Scanner(System.in);  
       
      int n;  
      File f = null;
      String s = "test1.txt";
      try {
            // create new file
            f = new File(s);
            String a = f.getAbsolutePath(); 
            FileWriter fout =new FileWriter(f);  
            BufferedWriter b=new BufferedWriter(fout);
            // prints absolute path 
            System.out.print("\n"+a);

            System.out.println("\nEnter the number of rows: ");
               
               try{
                n=scan.nextInt();
                  if(n==0)
                  throw new WrongChoiceException("table Name choice is Blank");
                  n=scan.nextInt();
                  }
                catch(WrongChoiceException e1)
                {
                System.out.println("Error"+e1.getMessage()); 
                }
    
           n=scan.nextInt();
            
            for(int i=0;i<n;i++)
            {
            String k=scan.nextLine();
            scan.next();
            }

         } 
            catch (Exception e) {
            // if any I/O error occurs
            e.printStackTrace();
         }  
   }
}
     
 
