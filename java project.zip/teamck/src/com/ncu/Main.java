import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.*;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class Main {
	public static final String ADD = "Add";
	public static final String SELECT = "Select";
	public static final String DELETE = "Delete";

	public static void main(String[] args) throws IOException {
		System.out.println("Enter in main");
		String filePath = "C:\\nmas\\Files\\Test.csv";
		File file = new File(filePath);
//
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter one of the following choices or enter 0 to exit ");
		System.out.println("1.Insert rows. \n 2. Delete rows. \n 3. Display records of table. \n 4. Display all tables in the database. ") ;
		int a = scan.nextInt();
		
		if(1== a){
			String data = scan.nextLine();
		System.out.println("data :" + data);
		String[] dataString = data.split(";");
		System.out.println("data1 :" + dataString[0]);
		args = new String[]{"ADD",dataString[0],dataString[1]};
		addNewRecord(file, dataString);
		}
		
//	
	/*if (args != null && args.length > 0) {

			String[] values = args[0].split(";");
			System.out.println("action :" + values[0]);
			if (ADD.equals(values[0])) {
				addNewRecord(file, values);
			} else if (SELECT.equals(values[0])) {
				selectRecords(file, values);
			} else if (DELETE.equals(values[0])) {
				deleteRecord(file, values);
			}
		}

	}*/
}
/*
	private static void deleteRecord(File file, String[] values) throws IOException {
		System.out.println("file :" + file);
	
		String line = "";
		String dbName = values[1];
		String tableName = values[2];
		int rowNumber = 0;
		boolean matched = false;
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			while ((line = br.readLine()) != null && !matched) {
				String[] value = line.split(",");
				String csvDBName = value[0];
				String csvTableName = value[1];
				rowNumber++;
				if (dbName.equals(csvDBName) && tableName.equals(csvTableName)) {
					System.out.println("Matched record DB Name :" + csvDBName + " Table Name :" + csvTableName);
					matched = true;
				}
			}

			System.out.println("Row NUmber :" + rowNumber);
			if (matched) {

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/

	/*private static void selectRecords(File file, String[] values) {
		String line = "";
		String dbName = values[1];
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			while ((line = br.readLine()) != null) {
				String value = line.split(",")[0];
				if (dbName.equals(value)) {
					System.out.println("Matched Table :" + value);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/

	public static boolean addNewRecord(File file, String[] record) {
		try {
			FileWriter outputFile = new FileWriter(file, true);
			CSVWriter writer = new CSVWriter(outputFile);
			String[] data = new String[] { record[0], record[1] };
			writer.writeNext(data);
			System.out.println("New Record added");

			writer.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

}
