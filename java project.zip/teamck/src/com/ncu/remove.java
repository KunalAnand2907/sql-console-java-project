import java.io.*;
import java.util.*;
//import com.ncu.*;

public class remove{

 





public static void removeRecord(){
     
    String filepath = "text.txt";
    int removeTerm = 4;
    Scanner x=new Scanner(System.in);

    String tempFile = "temp.txt";
    File oldFile = new File(filepath);
    File newFile = new File(tempFile);
    int POSITION =4,MATCHES_PLAYED =35,MATCHES_WON=25,MATCHES_LOST=4; 
    int POINTS =76,GOAL_DIFFERENCE=31;
    String TEAM_NAME= "LEVANTE";

    try {

        FileWriter fw = new FileWriter(tempFile,true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        x = new Scanner(System.in);
        x.useDelimiter("[,\n]");

        while (x.hasNext())
        {
            POSITION = x.nextInt();
            TEAM_NAME = x.next();
            MATCHES_PLAYED = x.nextInt();
            MATCHES_WON= x.nextInt();
            MATCHES_LOST = x.nextInt();
            POINTS = x.nextInt();
            GOAL_DIFFERENCE= x.nextInt();

            if(POSITION!=removeTerm)
            {
                System.out.println(POSITION+ ","+ TEAM_NAME+","+MATCHES_PLAYED+","+MATCHES_WON+","+MATCHES_LOST+","+POINTS+","+GOAL_DIFFERENCE);

            }
        
        }
        x.close();
        pw.flush();
        pw.close();
        oldFile.delete();
        File dump = new File (filepath);
        newFile.renameTo(dump);
    }

    catch(Exception e)
    {
      System.out.println("ERROR!");
    }
}
}