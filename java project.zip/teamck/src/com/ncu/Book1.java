//package com.ncu.*;
import java.io.*;


class Book1{
Book1()
{


File a=null;
          
            try {
            	
         
          File filepath = new File("text.txt");
          FileReader fin = new FileReader(filepath);
	      BufferedReader bin= new BufferedReader(fin);
          String r="POSITION,TEAM_NAME,MATCHES_PLAYED,MATCHES_WON,MATCHES_LOST,POINTS,GOAL_DIFFERENCE";
          String r1="1,BARCELONA,35,33,1,100,62";
          String r2="2,REAL MADRID,35,31,3,94,35";
          String r3="3,GIRONA FC,35,26,3,79,56";
          String r4="4,LEVANTE,35,25,4,76,31";
          String r5="5,SEVILA FC,35,24,5,73,29";

	      System.out.println("The contents of the file are: ");	
		    
		    
          System.out.println(r+"\n"+r1+"\n"+r2+"\n"+r3+"\n"+r4+"\n"+r5);

          }

catch (Exception e) 
         { 
            // if any I/O error occurs
            e.printStackTrace();
         }  
	
}
}




  