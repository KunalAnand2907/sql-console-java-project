import java.util.*;
import java.io.* ;



//import com.ncu.l;
//import com.exception;
//import package com.ncu.f;
class major1
{
	
	public static void main(String[] args) 
	{

	
			Scanner scan = new Scanner(System.in);
            
			System.out.println("Enter one of the following choices or enter 0 to exit ");
			System.out.println("1.Insert rows.  2. Delete rows.  3. Display records of table.  4. Display all tables in the database. ") ;
			
			
			
     int a=scan.nextInt();
    
			
			
				
            
			switch(a)
				{

				case 1 :
				System.out.println("Press 1 for Book1.  Press 2 for Book2.  Press 3 for Book3 ");
					
			    try{
			
                int b= scan.nextInt();
     
                if(b==0)
     
                throw new EmptyFileNameException("table Name choice is Blank");
                
                
        
                  }
                catch(EmptyFileNameException e)
                {
                System.out.println("Error"+e.getMessage());	
                }
		
				int b= scan.nextInt();


				switch(b)
				{
				case 1:
				System.out.println("Displaying Book1");
				Book1 r=new Book1();
				FileDemo g=new FileDemo();
				break;
				
				case 2: 
				System.out.println("Displaying Book2 ");
				Book2 e = new Book2();
				FileDemo l=new FileDemo();
				break;

				case 3:
                System.out.println("Displaying Book3");
                Book3 s=new Book3();
                FileDemo m=new FileDemo();
                break;
				}	
	
				break;

                


                case 2:

				System.out.println("Press 1 for Book1  Press 2 for Book2  Press 3 for Book3 ");
                int c=scan.nextInt();


                switch(c)
                {
                case 1:
                System.out.println("Displaying Book1  ");
				Book1 r=new Book1();
				remove.removeRecord();
                
                break;

                case 2:
                System.out.println("Displaying Book2 ");
				Book2 e = new Book2();
				RemoveALine.removeRecord();
				break;

                case 3:
                System.out.println("Displaying Book3");
                Book3 s=new Book3();
                rem.removeRecord();
                break;
                }
                break;




                case 3:
                System.out.println("Press 1 for Book1\n Press 2 for Book2\n Press 3 for Book3 ");
                int p=scan.nextInt();
               



                switch(p)
				{
				case 1:
				System.out.println("Displaying Book1  ");
				Book1 r=new Book1();
				break;
				
				case 2: 
				System.out.println("Displaying Book2 ");
				Book2 e = new Book2();
				break;

				case 3:
                System.out.println("Displaying Book3");
                Book3 s=new Book3();
                break;
				} 
				break;




				case 4:
				Book1 r=new Book1();
				Book2 e=new Book2();
				Book3 s=new Book3();
                break;


                case 5:
                System.out.println("error");

				}
				}
				}
